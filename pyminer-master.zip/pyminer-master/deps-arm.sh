#!/bin/bash

apt-get install -y make python2.7-dev