#!/bin/bash

CFLAGS="$CFLAGS"  make install
